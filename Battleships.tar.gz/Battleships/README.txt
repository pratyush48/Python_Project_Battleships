Team 7: A Game Has No Name

BATTLESHIPS
1. Functions.py is the definition of all the functions used in the game like random placement of the ships, checking for a hit or a miss, calculating end of game and grids for both players.

2. NewGame_1.py is the new game screen where the game can be played and which alternates with NewGame_2.py. It consists of two 10x10 grids with playable buttons which display red or yellow depending on hit or miss.

3. MainGame.py is the main game which combines the start screen with the game screen where the game is played. It is the integration of the GUI and Functions module.

4. Rules.py is the file containing the Rules section of the game.

5. About.py is the file containing the About section of the game.

6. NewGame_2.py is the alternative new game screen which switches with NewGame_1.py every time 'New Game' is pressed. It consists of two 10x10 grids with playable buttons which display red or yellow depending on hit or miss.


Creators:
Srihari Vemuru
Pratyush Nandi
Rahul Murali Shankar
